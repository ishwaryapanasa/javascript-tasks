const searchButton = document.getElementById('searchButton');
const cityInput = document.getElementById('cityInput');
const cityName = document.querySelector('.city-name');
const temperature = document.querySelector('.temperature');
const humidity = document.querySelector('.humidity');
const windspeed = document.querySelector('.windspeed');
const icon=document.querySelector('.weather-icon');
const dateElement=document.querySelector(".dateele");
const imageText= document.querySelector(".image-text");
const forecastContainer=document.querySelector("#forecast-container");
const day=document.getElementById('day');
const precipitation = document.querySelector('.precipitation');



const apiKey ='328d723a9a423c665cdd72906f0c6589';  
// Your actual API key


// Event listener for the search button
searchButton.addEventListener('click', () => {
    const city = cityInput.value.trim(); // Get city name
    if (city) {
        getWeatherData(city);
        getThreeDayForecast(city);
    } else {
        alert("Please enter a city name.");
    }
    forecastContainer.style.display="block";
});

// Function to fetch weather data from OpenWeather API
function getWeatherData(city) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('City not found');
            }
            return response.json();
        })
        .then(data => {
            // Update the UI with the weather data
            cityName.textContent = data.name;
            cityName.style.color="yellow"
            temperature.textContent = `${data.main.temp}°C`;
            humidity.textContent = `Humidity: ${data.main.humidity}%`;
            windspeed.textContent = `Wind Speed: ${data.wind.speed} km/h`;
            let precipitationValue = 0;
            if (data.rain && data.rain['1h']) {
                precipitationValue = data.rain['1h']; // Precipitation in mm for the last 1 hour
                precipitation.textContent = `Precipitation (Rain): ${precipitationValue} mm`;
            } else if (data.snow && data.snow['1h']) {
                precipitationValue = data.snow['1h']; // Precipitation in mm for the last 1 hour
                precipitation.textContent = `Precipitation (Snow): ${precipitationValue} mm`;
            } else {
                precipitation.textContent = 'No Precipitation';
            }

            if (data.main.temp > 10 && data.main.temp<20) {
                icon.src = 'images/sun2.jpg'; 
            }else if(data.main.temp<10){
                icon.src = 'images/cool.jpg';
            }else{
                icon.src='images/sun.jpg';
            }
            const now = new Date();
            const dayName = now.toLocaleDateString('en-US', { weekday: 'long' }); // Get day name
            const fullDate = now.toLocaleDateString(); // Get full date

            // Update date container with day and date in separate lines
            dateElement.innerHTML = `
                <h1 class="date">${dayName}</h1><br>
                <p class="day">${fullDate}</p>
            `;
        })
        .catch(error => {
            // Handle errors (e.g., city not found)
            cityName.textContent = "City not found";
            cityName.style.color="red";
            temperature.textContent = "--°C";
            humidity.textContent = "Humidity: --%";
            windspeed.textContent = "Wind Speed: -- km/h";
            
            
          
        
        });
    
}

// Function to fetch and display the 3-day forecast
function getThreeDayForecast(city) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            // Filter to get data at 12:00 PM (or change this as needed)
            const forecastData = data.list.filter(entry => entry.dt_txt.includes('12:00:00'));

            // Access forecast-container elements
            const day1Element = document.getElementById('day1');
            const day2Element = document.getElementById('day2');
            const day3Element = document.getElementById('day3');

            // Update each day's forecast data
            [day1Element, day2Element, day3Element].forEach((element, index) => {
                const forecast = forecastData[index];
                if (forecast) {
                    // Get and format the forecast date as "11 Nov 2024"
                    const forecastDate = new Date(forecast.dt * 1000);
                    const day = forecastDate.getDate();
                    const month = forecastDate.toLocaleString('en-US', { month: 'short' });
                    const year = forecastDate.getFullYear();
                    const formattedDate = `${day} ${month} ${year}`;

                    const forecastTemp = forecast.main.temp;
                    const forecastDescription = forecast.weather[0].description;
                    const forecastIcon = forecast.weather[0].icon;

                    element.innerHTML = `
                    <div class="forecast-container">
                        <div class="forecast-details">
                            <h3>${formattedDate}</h3>  <!-- Display formatted date here -->
                            <p>Weather: ${forecastDescription}</p>
                            <p>Temperature: ${forecastTemp}°C</p>
                        </div>
                        <img src="http://openweathermap.org/img/wn/${forecastIcon}.png" alt="Weather Icon">
                    </div>
                `;
                }
            });
        })
        .catch(error => {
            console.error('Error fetching 3-day forecast:', error);
        });
}


            